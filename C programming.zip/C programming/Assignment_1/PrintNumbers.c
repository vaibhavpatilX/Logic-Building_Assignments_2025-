#include<stdio.h>

void Display()
{
    int i = 0;
    i = 5;
    for(i=1;i<=5;i)
    {
        printf("%d",i);
        i++;
    }
}
int main()
{
    Display();
    
    return 0;
}